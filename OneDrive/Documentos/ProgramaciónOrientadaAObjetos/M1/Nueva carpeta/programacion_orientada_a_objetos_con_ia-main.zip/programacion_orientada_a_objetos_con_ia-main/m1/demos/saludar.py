# Solicitar el nombre del usuario
nombre = input("¿Cuál es tu nombre? ")

# Saludar al usuario
print(f"¡Hola, {nombre}! ¡Espero que tengas un excelente día!")
