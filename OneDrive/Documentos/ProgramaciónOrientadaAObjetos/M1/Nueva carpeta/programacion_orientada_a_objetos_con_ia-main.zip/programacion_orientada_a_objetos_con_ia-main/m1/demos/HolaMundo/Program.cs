﻿        // Pregunta el nombre al usuario
        Console.Write("¿Cuál es tu nombre? ");
        string nombre = Console.ReadLine();

        // Saluda al usuario
        Console.WriteLine($"¡Hola, {nombre}!");
        Console.WriteLine("¡Bienvenido a C#!");
        Console.Clear();
        Console.ReadLine();


